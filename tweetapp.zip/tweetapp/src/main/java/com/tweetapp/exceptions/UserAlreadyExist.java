package com.tweetapp.exceptions;

public class UserAlreadyExist extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public UserAlreadyExist(String msg) {
		super(msg);
	}

}
