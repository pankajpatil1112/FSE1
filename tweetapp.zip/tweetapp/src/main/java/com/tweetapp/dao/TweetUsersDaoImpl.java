package com.tweetapp.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Component;

import com.mongodb.MongoWriteException;
import com.mongodb.client.result.UpdateResult;
import com.tweetapp.entity.Tweet;
import com.tweetapp.entity.User;
import com.tweetapp.exceptions.UserAlreadyExist;
import com.tweetapp.repository.TweetUsersRepository;

@Component
public class TweetUsersDaoImpl implements TweetUsersDao {

	@Autowired
	TweetUsersRepository tweetUsersRepository;

	@Autowired
	MongoTemplate mongoTemplate;

	@Override
	public boolean saveUser(User user) throws UserAlreadyExist {
		User saveUser = null;
		try {
			saveUser = tweetUsersRepository.insert(user);
		} catch (MongoWriteException e) {
			throw new UserAlreadyExist("User Already Exist with " + user.getUserId());
		}
		return saveUser == null ? false : true;
	}

	@Override
	public boolean addPost(String id, Tweet tweet) {
		Update update = new Update();
		update.push("tweets", tweet);
		Criteria criteria = Criteria.where("_id").is(id);
		UpdateResult result = mongoTemplate.updateFirst(Query.query(criteria), update, User.class);
		if (result.getModifiedCount() > 0)
			return true;
		return false;
	}

	@Override
	public boolean updateStatus(String id, boolean status) {

		Update update = new Update();
		update.set("status", status);
		Criteria criteria = Criteria.where("_id").is(id);
		UpdateResult result = mongoTemplate.updateFirst(Query.query(criteria), update, User.class);
		if (result.getModifiedCount() > 0)
			return true;
		return false;
	}

	@Override
	public User getUser(String userId) {
		Optional<User> user = tweetUsersRepository.findById(userId);
		return user.get();
	}

	@Override
	public List<User> getAllUsers() {
		List<User> userList = tweetUsersRepository.findAll();
		return userList;
	}

	@Override
	public boolean updatePassword(String userId, String password) {
		Update update = new Update();
		update.set("password", password);
		Criteria criteria = Criteria.where("_id").is(userId);
		UpdateResult result = mongoTemplate.updateFirst(Query.query(criteria), update, User.class);
		if (result.getModifiedCount() > 0)
			return true;
		return false;

	}

	@Override
	public boolean forgotPassword(String userId, String userName, String password) {
		Update update = new Update();
		update.set("password", password);
		Criteria criteria = Criteria.where("_id").is(userId).and("userName").is(userName);
		UpdateResult result = mongoTemplate.updateFirst(Query.query(criteria), update, User.class);
		if (result.getModifiedCount() > 0)
			return true;
		return false;

	}

}
