package com.tweetapp.dao;

import java.util.List;

import org.springframework.stereotype.Component;

import com.tweetapp.entity.Tweet;
import com.tweetapp.entity.User;
import com.tweetapp.exceptions.UserAlreadyExist;

@Component
public interface TweetUsersDao {
	public boolean saveUser(User user) throws UserAlreadyExist;

	public boolean addPost(String id, Tweet tweet);

	public User getUser(String userId);

	public List<User> getAllUsers();

	public boolean updateStatus(String id, boolean status);

	public boolean updatePassword(String userId, String password);

	public boolean forgotPassword(String userId, String userName, String password);
}
