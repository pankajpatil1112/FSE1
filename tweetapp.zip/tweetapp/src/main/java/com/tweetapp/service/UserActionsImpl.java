package com.tweetapp.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tweetapp.dao.TweetUsersDaoImpl;
import com.tweetapp.entity.Tweet;
import com.tweetapp.entity.User;
import com.tweetapp.exceptions.UserAlreadyExist;

@Service
public class UserActionsImpl implements UserActions {
	@Autowired
	TweetUsersDaoImpl tweetUsersDaoImpl;

	@Override
	public void registerNewUser(User user) throws UserAlreadyExist {

		if (tweetUsersDaoImpl.saveUser(user)) {
			System.out.println(user.getUserName() + "saved successfully!");
		}

	}

	@Override
	public void postTweet(Tweet tweet, String userId) {

		tweetUsersDaoImpl.addPost(userId, tweet);

	}

	@Override
	public List<Tweet> getUserTweets(String userId) {

		return tweetUsersDaoImpl.getUser(userId).getTweets();
	}

	@Override
	public Map<String, List<Tweet>> getAllTweets() {
		Map<String, List<Tweet>> map = new HashMap<>();
		tweetUsersDaoImpl.getAllUsers().stream().filter(user -> user.getTweets() != null)
				.forEach(user -> map.put(user.getUserId(), user.getTweets()));
		return map;
	}

	@Override
	public List<User> getAllUsers() {

		return tweetUsersDaoImpl.getAllUsers();
	}

	@Override
	public User login(String userId, String password) {
		User user = tweetUsersDaoImpl.getUser(userId);
		if (user.getPassword().equals(password)) {
			tweetUsersDaoImpl.updateStatus(userId, true);
			return user;
		}

		return null;
	}

	@Override
	public boolean logout(String userId) {
		return tweetUsersDaoImpl.updateStatus(userId, false);

	}

}
