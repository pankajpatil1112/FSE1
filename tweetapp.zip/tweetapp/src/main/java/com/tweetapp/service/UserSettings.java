package com.tweetapp.service;

import org.springframework.stereotype.Service;

@Service
public interface UserSettings {

	public void resetPassword(String userId, String newPassword);

	public boolean forgotPassword(String userId, String name, String password);

}
