package com.tweetapp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tweetapp.dao.TweetUsersDao;

@Service
public class UserSettingsImpl implements UserSettings {
	@Autowired
	TweetUsersDao tweetUserDao;

	@Override
	public void resetPassword(String userId, String newPassword) {
		tweetUserDao.updatePassword(userId, newPassword);
	}

	@Override
	public boolean forgotPassword(String userId, String name, String password) {
		return tweetUserDao.forgotPassword(userId, name, password);

	}

}
