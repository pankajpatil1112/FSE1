package com.tweetapp.service;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.tweetapp.entity.Tweet;
import com.tweetapp.entity.User;
import com.tweetapp.exceptions.UserAlreadyExist;

@Service
public interface UserActions {
	public void registerNewUser(User user) throws UserAlreadyExist;

	public void postTweet(Tweet tweet, String userId);

	public List<Tweet> getUserTweets(String userId);

	public Map<String, List<Tweet>> getAllTweets();

	public User login(String userId, String password);

	public boolean logout(String userId);

	public List<User> getAllUsers();
}
